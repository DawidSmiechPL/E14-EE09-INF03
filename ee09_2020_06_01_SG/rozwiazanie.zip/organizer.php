<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Organizer</title>
    <link rel="stylesheet" href="styl6.css">
</head>
<body>

    <header>
        <section class="head1">
            <h2>MÓJ ORGANIEZER</h2>
        </section>
        <section class="head2">
            <form action="" method="POST">
                Wpis wydarzenia: <input type="text" name="wpis"><button type="submit" name="wyslij">ZAPISZ</button>
            </form>
        </section>
        <section class="head3">
            <img src="logo2.png" alt="Mój organizer">
        </section>
    </header>

    <main>
        <?php
            $pol = mysqli_connect('localhost', 'root', '', 'egzamin6');

            if(isset($_POST['wyslij'])){
                $wpis = $_POST['wpis'];
                $zapytanie1 = mysqli_query($pol, "UPDATE zadania SET wpis = '$wpis' WHERE dataZadania = '2020-08-27';");
            }
            $zapytanie2 = mysqli_query($pol, "SELECT dataZadania, miesiac, wpis FROM zadania");
            while ($row=mysqli_fetch_row($zapytanie2)){
                echo "<section class=blok><h6>$row[0],$row[1]</h6><p>$row[2]</p></section>";
            }
        ?>
    </main>

    <footer>
        <?php  
            $zapytanie3 = mysqli_query($pol, "SELECT miesiac, rok FROM zadania");
            $row2 = mysqli_fetch_row($zapytanie3);
            echo "<h1>miesiąc: $row2[0], rok: $row2[1]</h2>";
        ?>
        <p>Stronę wykonał: Dawid Śmiech</p>
    </footer>
</body>
</html>