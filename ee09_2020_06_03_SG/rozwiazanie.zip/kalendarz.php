<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl5.css">
    <title>Mój kalendarz</title>
</head>
<body>
    <header>
        <section class="banner1">
            <img src="logo1.png" alt="Mój kalendarz">
        </section>
        <section class="banner2">
            <h1>KALENDARZ</h1>
            <?php
            $pol = mysqli_connect('localhost', 'root', '', 'egzamin5');
            $zapytanie1 = mysqli_query($pol, "SELECT miesiac, rok FROM zadania;");
            $wynik1 = mysqli_fetch_row($zapytanie1);
            echo "<p>miesiąc: $wynik1[0], rok: $wynik1[1]</p>";
            ?>
        </section>
    </header>
    <main>
        <section>

        </section>
        <?php
            if(isset($_POST['wyslij'])){
                $wartosc = $_POST['wpis'];
                $zapytanie3 = mysqli_query($pol, "UPDATE zadania SET wpis = '$wartosc' WHERE dataZadania LIKE '2020-07-13';");
            }
            $zapytanie2 = mysqli_query($pol, "SELECT dataZadania, wpis FROM zadania;");
            while ($row = mysqli_fetch_array($zapytanie2)) {
                echo "<section class=zadania><h5>$row[0]</h5><p>$row[1]</p></section>";
            } 
            mysqli_close($pol);
        ?>
    </main>
    <footer>
        <form action="" method="POST">
            Dodaj wpis: <input name="wpis" type="text">
            <button type="submit" name="wyslij">DODAJ</button>
        </form>
        <p>Stronę wykonał: Dawid Śmiech</p>
    </footer>
</body>
</html>